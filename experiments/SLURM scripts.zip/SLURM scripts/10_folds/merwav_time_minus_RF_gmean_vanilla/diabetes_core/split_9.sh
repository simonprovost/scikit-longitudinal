#!/bin/bash

# ========================================
# SLURM Configuration
# ========================================
#SBATCH --job-name="DATA_PREP_DIABETES_CORE_MERWAV_TIME_MINUS_RF_GMEAN_VANILLA_split_9"
#SBATCH --output="DATA_PREP_DIABETES_CORE_MERWAV_TIME_MINUS_RF_GMEAN_VANILLA_split_9_%j.log"
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user="your_email"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=1GB
#SBATCH --partition=cpu

# ========================================
# Experiment Variables
# ========================================
N_OUTER_SPLITS=10

DATASET_PATH="../scikit_longitudinal/data/elsa/core/csv/diabetes_dataset.csv"
TARGET_COLUMN="class_diabetes_w8"
FOLD_NUMBER=9
EXPORT_NAME="DATA_PREP_DIABETES_CORE_MERWAV_TIME_MINUS_RF_GMEAN_VANILLA"
METRIC_TO_OPTIM="GMean"
IMBALANCED_SETUP="vanilla"

# ========================================
# Environment Setup (NO NEED TO MODIFY)
# ========================================
source ~/miniconda3/etc/profile.d/conda.sh
export PATH="<path_to>miniconda3/bin/:$PATH"
export PATH="<path_to>.local/bin/:$PATH"
export PATH="<path_to>.pyenv/bin/:$PATH"
pyenv local 3.9.8
pdm use 3.9
export PDM_IN_ENV=in-project
cd <path_to>Auto-Sklong
eval $(pdm venv activate $PDM_IN_ENV)

# ========================================
# Run Experiment (NO NEED TO MODIFY)
# ========================================
python ./experiments/experiment_launchers/merwav_time_minus_random_forest.py --dataset_path $DATASET_PATH --target_column $TARGET_COLUMN --fold_number $FOLD_NUMBER --export_name $EXPORT_NAME --n_outer_splits $N_OUTER_SPLITS --opt_metric $METRIC_TO_OPTIM --sampler $IMBALANCED_SETUP
